'''
    antidote - A Script kiddies buster tool

    Being a script kid is not bad. But using someone else's 
    tools and script to harm others is absolutely bad. 
    And this thing is actually needed right now.
'''
__version__ = '0.1.0'
